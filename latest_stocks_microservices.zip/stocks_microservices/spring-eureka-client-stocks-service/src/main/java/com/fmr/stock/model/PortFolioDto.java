package com.fmr.stock.model;

public class PortFolioDto {
	private String portfolioId;

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	

}
