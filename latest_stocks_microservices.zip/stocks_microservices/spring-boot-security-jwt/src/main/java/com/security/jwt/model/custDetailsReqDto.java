package com.security.jwt.model;

public class custDetailsReqDto {
	private String custid;

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}
	
	
}
