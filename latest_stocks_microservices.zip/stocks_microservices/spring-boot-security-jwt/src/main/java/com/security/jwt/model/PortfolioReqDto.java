package com.security.jwt.model;

public class PortfolioReqDto {
	
	private String portfolioId;

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	
	

}
