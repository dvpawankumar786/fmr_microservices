insert into PORTFOLIO values ('830466','1192307','830400','29:04:2021');

