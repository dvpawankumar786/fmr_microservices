insert into role values ('7','role for user','USER');
INSERT INTO fmr_user VALUES ('7','27','830466','$2a$10$Q9pk1Waz32nExKQmR/X1Jeu7gTIBZ/uCMT3ps/GEIY60Ya64Rgkye','5555556','PawanDv');
insert into user_roles values ('7','7');