insert into STOCKS values ('83467','12322','0.2','0.9','100','NYC99','TATA','STOCK');
insert into STOCKS values ('1192307','830400','0.2','0.9','100','NYC','JIO','STOCK');

insert into STOCKSMASTER values ('83146','0.33','7','1','NYC09','28','STOCK');
insert into STOCKSMASTER values ('981374','0.33','7','1','NYC9','28','STOCK');
insert into STOCKSMASTER values ('213446','0.33','7','1','NYC60','28','STOCK');
insert into STOCKSMASTER values ('8126346','0.33','7','1','NC','28','STOCK');
insert into STOCKSMASTER values ('6846','0.33','7','1','NYC1','28','STOCK');
insert into STOCKSMASTER values ('834646','0.33','7','1','NSC','28','STOCK');
insert into STOCKSMASTER values ('32346','0.33','7','1','NYC9','28','STOCK');
insert into STOCKSMASTER values ('4384646','0.33','7','1','NY99','28','STOCK');


